# Beacon — disaster safety app

Live map of people around you, crowd-scanned building floor plans with marked
exits, status check-ins, one-tap emergency calling, and post-event coping tools.
React Native (Expo dev build) + a small Node/Socket.IO backend.

## Run it (you already have this set up)
Two terminal tabs from the project root:

    npx expo start --dev-client        # serves the app to your phone
    cd server && node server.js        # serves buildings + live presence

Then open Beacon on your phone. IP lives in src/net.js (currently 10.0.0.61:4000
— update if your Wi-Fi changes: ipconfig getifaddr en0).

## Rebuild after 7 days (free cert expires)
    npx expo run:ios --device

## Features
- Onboarding (name, phone, permissions, circle, role, honesty pledge) — saved once
- Building select: pick a scanned building or scan a new one
- Scan flow: photograph the floor plan, TAP to place exits, tap a pin to flip
  clear/blocked (green/red), long-press to remove
- Map: real Google/Apple map, your GPS, live dots for others in your building,
  Floor plan button showing the plan with exit pins
- People: circle with status, tap for location + directions + call
- SOS: real tel:911 behind a confirm, quick contacts
- Recover: 4-4-4 breathing, grounding, crisis line
- Settings: role switch, dark mode, current building, honesty toggle

## Honest limits (good to say at judging)
- Google Maps has no indoor data; the scanned plan is an image, not geometry
- Exit status is set by the scanner and stays fixed (live crowd-sourcing = future work)
- Presence needs the network up; a real deployment needs mesh/BLE fallback
- Push notifications need a paid Apple account (future work)
- Server is in-memory; restart clears it. Swap for a DB before anything real
