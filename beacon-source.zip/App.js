import React, { useEffect, useState } from 'react';
import { View, TouchableOpacity, ActivityIndicator, StyleSheet } from 'react-native';
import { NavigationContainer, DefaultTheme, DarkTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';

import { ThemeProvider, useTheme } from './src/ThemeContext';
import { loadState, saveOnboarded, saveRole, saveBuilding } from './src/storage';
import Onboarding from './src/screens/Onboarding';
import BuildingSelect from './src/screens/BuildingSelect';
import AddBuilding from './src/screens/AddBuilding';
import Status from './src/screens/Status';
import MapScreen from './src/screens/MapScreen';
import People from './src/screens/People';
import PersonDetail from './src/screens/PersonDetail';
import SOS from './src/screens/SOS';
import Recover from './src/screens/Recover';
import Settings from './src/screens/Settings';

const Tab = createBottomTabNavigator();
const Stack = createNativeStackNavigator();
const ICONS = { Status: 'pulse-outline', Map: 'map-outline', People: 'people-outline', Recover: 'heart-outline' };

function SOSTabButton({ children, onPress }) {
  const { colors } = useTheme();
  return (
    <TouchableOpacity style={s.sosTab} onPress={onPress} activeOpacity={0.85}>
      <View style={[s.sosCircle, { backgroundColor: colors.danger, borderColor: colors.surface }]}>{children}</View>
    </TouchableOpacity>
  );
}

function Tabs({ role, building }) {
  const { colors } = useTheme();
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: colors.brand,
        tabBarInactiveTintColor: colors.muted,
        tabBarStyle: { height: 64, paddingBottom: 10, paddingTop: 6, backgroundColor: colors.card, borderTopColor: colors.border },
        tabBarLabelStyle: { fontSize: 10 },
        tabBarIcon: ({ color }) => route.name === 'SOS'
          ? <Ionicons name="alert-circle" size={24} color="#fff" />
          : <Ionicons name={ICONS[route.name]} size={22} color={color} />,
      })}
    >
      <Tab.Screen name="Status">{(p) => <Status {...p} role={role} building={building} />}</Tab.Screen>
      <Tab.Screen name="Map">{(p) => <MapScreen {...p} role={role} building={building} />}</Tab.Screen>
      <Tab.Screen name="SOS"
        options={{ tabBarButton: (p) => <SOSTabButton {...p} />, tabBarActiveTintColor: colors.danger, tabBarInactiveTintColor: colors.danger }}>{(p) => <SOS {...p} role={role} />}</Tab.Screen>
      <Tab.Screen name="People">{(p) => <People {...p} role={role} building={building} />}</Tab.Screen>
      <Tab.Screen name="Recover" component={Recover} />
    </Tab.Navigator>
  );
}

function Root() {
  const { colors, dark } = useTheme();
  const [ready, setReady] = useState(false);
  const [onboarded, setOnboarded] = useState(false);
  const [role, setRoleState] = useState('community');
  const [building, setBuildingState] = useState(null);

  useEffect(() => {
    loadState().then((st) => { setOnboarded(st.onboarded); setRoleState(st.role); setBuildingState(st.building); setReady(true); });
  }, []);

  const setRole = (r) => { setRoleState(r); saveRole(r); };
  const pickBuilding = (b) => { setBuildingState(b); saveBuilding(b); };

  const navTheme = dark
    ? { ...DarkTheme, colors: { ...DarkTheme.colors, background: colors.surface, card: colors.card } }
    : { ...DefaultTheme, colors: { ...DefaultTheme.colors, background: colors.surface } };

  if (!ready) return <View style={{ flex: 1, backgroundColor: colors.surface, alignItems: 'center', justifyContent: 'center' }}><ActivityIndicator color={colors.brand} /></View>;

  return (
    <NavigationContainer theme={navTheme}>
      <StatusBar style={dark ? 'light' : 'dark'} />
      {!onboarded ? (
        <Onboarding onDone={({ community, profile }) => { const r = community ? 'community' : 'responder'; setRoleState(r); saveOnboarded(r, profile); setOnboarded(true); }} />
      ) : !building ? (
        <BuildingStack onPick={pickBuilding} />
      ) : (
        <Stack.Navigator screenOptions={{ headerShown: false }}>
          <Stack.Screen name="Tabs">{() => <Tabs role={role} building={building} />}</Stack.Screen>
          <Stack.Screen name="PersonDetail" component={PersonDetail} />
          <Stack.Screen name="Settings">{(p) => <Settings {...p} role={role} setRole={setRole} building={building} onChangeBuilding={() => p.navigation.navigate('ChangeBuilding')} />}</Stack.Screen>
          <Stack.Screen name="ChangeBuilding" component={BuildingSelect} initialParams={{ onPick: pickBuilding }} />
          <Stack.Screen name="AddBuilding" component={AddBuilding} initialParams={{ onPick: pickBuilding }} />
        </Stack.Navigator>
      )}
    </NavigationContainer>
  );
}

function BuildingStack({ onPick }) {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="BuildingSelect" component={BuildingSelect} initialParams={{ onPick }} />
      <Stack.Screen name="AddBuilding" component={AddBuilding} initialParams={{ onPick }} />
    </Stack.Navigator>
  );
}

export default function App() {
  return (
    <SafeAreaProvider>
      <ThemeProvider><Root /></ThemeProvider>
    </SafeAreaProvider>
  );
}

const s = StyleSheet.create({
  sosTab: { top: -18, justifyContent: 'center', alignItems: 'center' },
  sosCircle: { width: 50, height: 50, borderRadius: 25, justifyContent: 'center', alignItems: 'center', borderWidth: 4 },
});
