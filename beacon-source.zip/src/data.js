export const circle = [
  { id: '1', name: 'Mom',           initials: 'MM', status: 'safe',        where: 'Home',                    inBuilding: false, coord: { latitude: 33.108, longitude: -96.834 } },
  { id: '2', name: 'Dad',           initials: 'DD', status: 'safe',        where: 'Downtown office',         inBuilding: false, coord: { latitude: 33.150, longitude: -96.823 } },
  { id: '3', name: 'Aria (sister)', initials: 'AR', status: 'noresponse',  where: 'Last seen: Sunrise, Fl 3',inBuilding: true,  coord: { latitude: 33.1212, longitude: -96.8121 } },
  { id: '4', name: 'Sam (neighbor)',initials: 'SK', status: 'help',        where: 'Sunrise Office · Break rm',inBuilding: true, coord: { latitude: 33.1209, longitude: -96.8118 } },
  { id: '5', name: 'Coach Ravi',    initials: 'RV', status: 'safe',        where: 'Rec center',              inBuilding: false, coord: { latitude: 33.134, longitude: -96.801 } },
];
export const statusMeta = {
  safe:       { label: 'Safe',        color: '#22A559' },
  noresponse: { label: 'No response', color: '#E8792B' },
  help:       { label: 'Needs help',  color: '#E23B3B' },
};
export function crowdAround(center, n = 50) {
  const out = [];
  for (let i = 0; i < n; i++) {
    out.push({ id: 'p' + i, coord: { latitude: center.latitude + (Math.random() - 0.5) * 0.004, longitude: center.longitude + (Math.random() - 0.5) * 0.004 }, needsHelp: i < 3 });
  }
  return out;
}
