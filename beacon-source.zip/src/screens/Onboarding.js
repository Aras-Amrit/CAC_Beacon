import React, { useMemo, useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, ScrollView, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as Location from 'expo-location';
import * as Contacts from 'expo-contacts';
import { useTheme } from '../ThemeContext';
import { circle as seedCircle } from '../data';

const STEPS = 6;

export default function Onboarding({ onDone }) {
  const { colors } = useTheme();
  const s = useMemo(() => makeStyles(colors), [colors]);
  const [step, setStep] = useState(0);
  const [perms, setPerms] = useState({ location: false, contacts: false, notifications: false });
  const [picked, setPicked] = useState({ '1': true, '2': true });
  const [community, setCommunity] = useState(true);
  const [pledge, setPledge] = useState(true);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');

  const next = () => (step < STEPS - 1 ? setStep(step + 1) : onDone({ community, profile: { name, phone } }));
  const back = () => step > 0 && setStep(step - 1);

  async function ask(kind) {
    try {
      if (kind === 'location') await Location.requestForegroundPermissionsAsync();
      if (kind === 'contacts') await Contacts.requestPermissionsAsync();
    } catch (e) {}
    setPerms((p) => ({ ...p, [kind]: true }));
  }

  const selectedCount = Object.values(picked).filter(Boolean).length;
  const labels = ['Get started', 'Continue', 'Continue', 'Continue', 'Continue', 'Enter Beacon'];

  return (
    <View style={{ flex: 1, backgroundColor: colors.surface }}>
      <View style={s.progressRow}>
        <TouchableOpacity onPress={back} style={{ opacity: step === 0 ? 0 : 1, paddingRight: 8 }}>
          <Ionicons name="arrow-back" size={22} color={colors.muted} />
        </TouchableOpacity>
        {Array.from({ length: STEPS }).map((_, i) => (
          <View key={i} style={[s.bar, { backgroundColor: i <= step ? colors.brand : colors.borderInput }]} />
        ))}
      </View>

      <ScrollView contentContainerStyle={{ padding: 22, paddingBottom: 12 }}>
        {step === 0 && (
          <View style={{ alignItems: 'center', paddingTop: 20 }}>
            <View style={s.logo}><Ionicons name="radio-outline" size={40} color="#fff" /></View>
            <Text style={s.h1}>Beacon</Text>
            <Text style={s.sub}>Stay found. Stay safe. Stay together.</Text>
            <View style={{ marginTop: 26, alignSelf: 'stretch' }}>
              <Feature s={s} colors={colors} icon="map-outline" bg={colors.tint} fg={colors.brandDark} title="See who's around you" desc="Live map of people in your building" />
              <Feature s={s} colors={colors} icon="exit-outline" bg={colors.cautionBg} fg={colors.cautionText} title="Get guided to safety" desc="Routes to the nearest clear exit" />
              <Feature s={s} colors={colors} icon="alert-circle-outline" bg={colors.dangerBg} fg={colors.dangerText} title="Call for help fast" desc="One tap to responders and your people" />
            </View>
          </View>
        )}

        {step === 1 && (
          <View>
            <Text style={s.h2}>Let's set you up</Text>
            <Text style={s.sub2}>Your phone number lets responders and your circle reach you in an emergency.</Text>
            <Field s={s} colors={colors} label="Full name" placeholder="Aaras Kumar" value={name} onChangeText={setName} />
            <Field s={s} colors={colors} label="Phone number" placeholder="(469) 555-0134" keyboardType="phone-pad" value={phone} onChangeText={setPhone} />
            <Field s={s} colors={colors} label="Home address · optional" placeholder="1420 Maple Ave, Frisco TX" />
          </View>
        )}

        {step === 2 && (
          <View>
            <Text style={s.h2}>A few permissions</Text>
            <Text style={s.sub2}>Beacon needs these to work when it matters. Change them anytime in Settings.</Text>
            <Perm s={s} colors={colors} k="location" icon="location-outline" title="Location" desc="So people can find you during an alert" perms={perms} ask={ask} />
            <Perm s={s} colors={colors} k="contacts" icon="people-outline" title="Contacts" desc="To add your circle in one tap" perms={perms} ask={ask} />
            <Perm s={s} colors={colors} k="notifications" icon="notifications-outline" title="Notifications" desc="Earthquake, fire, and flood warnings" perms={perms} ask={ask} />
          </View>
        )}

        {step === 3 && (
          <View>
            <Text style={s.h2}>Add your circle</Text>
            <Text style={s.sub2}>Pick people to auto-notify with your status and location.</Text>
            {seedCircle.map((p) => {
              const on = !!picked[p.id];
              return (
                <TouchableOpacity key={p.id} onPress={() => setPicked((x) => ({ ...x, [p.id]: !on }))}
                  style={[s.row, { borderColor: on ? colors.brand : colors.border }]}>
                  <View style={s.avatar}><Text style={s.avatarT}>{p.initials}</Text></View>
                  <Text style={{ flex: 1, fontSize: 14, fontWeight: '500', color: colors.ink }}>{p.name}</Text>
                  <Ionicons name={on ? 'checkmark-circle' : 'ellipse-outline'} size={22} color={on ? colors.brand : colors.iconMuted} />
                </TouchableOpacity>
              );
            })}
            <Text style={{ textAlign: 'center', color: colors.brandDark, fontWeight: '500', marginTop: 10 }}>{selectedCount} selected</Text>
          </View>
        )}

        {step === 4 && (
          <View>
            <Text style={s.h2}>How will you use Beacon?</Text>
            <Text style={s.sub2}>This changes what you see during an emergency.</Text>
            <RoleOpt s={s} colors={colors} active={community} onPress={() => setCommunity(true)} icon="people-outline" title="Community member" desc="See your status, find your people, get to safety" />
            <RoleOpt s={s} colors={colors} active={!community} onPress={() => setCommunity(false)} icon="shield-half-outline" title="First responder" desc="See everyone in a building, who's trapped, headcounts" />
            <TouchableOpacity onPress={() => setPledge(!pledge)} style={s.pledge}>
              <View style={[s.check, { backgroundColor: pledge ? colors.brand : colors.card, borderWidth: pledge ? 0 : 2, borderColor: colors.iconMuted }]}>
                {pledge && <Ionicons name="checkmark" size={16} color="#fff" />}
              </View>
              <Text style={{ flex: 1, fontSize: 12, color: colors.textSec, lineHeight: 18 }}>
                <Text style={{ fontWeight: '500', color: colors.ink }}>I'll report honestly. </Text>
                I'll only mark myself safe if I truly am — rescuers use this to decide who to reach first.
              </Text>
            </TouchableOpacity>
          </View>
        )}

        {step === 5 && (
          <View style={{ alignItems: 'center', paddingTop: 40 }}>
            <View style={s.doneCircle}><Ionicons name="checkmark" size={44} color={colors.brand} /></View>
            <Text style={s.h2}>You're all set</Text>
            <Text style={[s.sub2, { textAlign: 'center' }]}>Next, pick the building you're in. Beacon is watching for alerts in your area.</Text>
          </View>
        )}
      </ScrollView>

      <View style={{ padding: 22, paddingTop: 8 }}>
        <TouchableOpacity style={s.cta} onPress={next}><Text style={s.ctaT}>{labels[step]}</Text></TouchableOpacity>
      </View>
    </View>
  );
}

const Feature = ({ s, colors, icon, bg, fg, title, desc }) => (
  <View style={{ flexDirection: 'row', gap: 12, alignItems: 'center', marginBottom: 14 }}>
    <View style={[s.featIcon, { backgroundColor: bg }]}><Ionicons name={icon} size={20} color={fg} /></View>
    <View style={{ flex: 1 }}>
      <Text style={{ fontSize: 14, fontWeight: '500', color: colors.ink }}>{title}</Text>
      <Text style={{ fontSize: 12, color: colors.muted }}>{desc}</Text>
    </View>
  </View>
);
const Field = ({ s, colors, label, ...rest }) => (
  <View style={{ marginBottom: 16 }}>
    <Text style={{ fontSize: 12, color: colors.textSec, fontWeight: '500', marginBottom: 6 }}>{label}</Text>
    <TextInput style={s.input} placeholderTextColor={colors.muted} {...rest} />
  </View>
);
const Perm = ({ s, colors, k, icon, title, desc, perms, ask }) => {
  const on = perms[k];
  return (
    <View style={[s.row, { borderColor: colors.border }]}>
      <View style={[s.featIcon, { backgroundColor: colors.tint }]}><Ionicons name={icon} size={20} color={colors.brandDark} /></View>
      <View style={{ flex: 1 }}>
        <Text style={{ fontSize: 14, fontWeight: '500', color: colors.ink }}>{title}</Text>
        <Text style={{ fontSize: 11, color: colors.muted }}>{desc}</Text>
      </View>
      <TouchableOpacity onPress={() => ask(k)} style={[s.allow, on && { backgroundColor: colors.tint }]}>
        <Text style={{ color: on ? colors.brandDark : '#fff', fontWeight: '500', fontSize: 13 }}>{on ? 'Allowed' : 'Allow'}</Text>
      </TouchableOpacity>
    </View>
  );
};
const RoleOpt = ({ s, colors, active, onPress, icon, title, desc }) => (
  <TouchableOpacity onPress={onPress} style={[s.roleOpt, { borderWidth: active ? 2 : 1, borderColor: active ? colors.brand : colors.border, backgroundColor: active ? colors.tint : colors.card }]}>
    <Ionicons name={icon} size={24} color={active ? colors.brandDark : colors.textSec} />
    <View style={{ flex: 1 }}>
      <Text style={{ fontSize: 15, fontWeight: '500', color: colors.ink }}>{title}</Text>
      <Text style={{ fontSize: 12, color: colors.textSec }}>{desc}</Text>
    </View>
    <Ionicons name={active ? 'checkmark-circle' : 'ellipse-outline'} size={22} color={active ? colors.brand : colors.iconMuted} />
  </TouchableOpacity>
);

function makeStyles(c) {
  return StyleSheet.create({
    progressRow: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 22, paddingTop: 16, paddingBottom: 4 },
    bar: { flex: 1, height: 4, borderRadius: 2 },
    logo: { width: 74, height: 74, borderRadius: 20, backgroundColor: c.brand, alignItems: 'center', justifyContent: 'center', marginBottom: 18 },
    h1: { fontSize: 26, fontWeight: '500', color: c.ink },
    h2: { fontSize: 22, fontWeight: '500', color: c.ink },
    sub: { fontSize: 14, color: c.muted, marginTop: 4 },
    sub2: { fontSize: 13, color: c.muted, marginTop: 4, marginBottom: 18 },
    featIcon: { width: 40, height: 40, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
    input: { borderWidth: 1, borderColor: c.borderInput, borderRadius: 11, padding: 12, fontSize: 14, backgroundColor: c.card, color: c.ink },
    row: { flexDirection: 'row', alignItems: 'center', gap: 11, backgroundColor: c.card, borderWidth: 1, borderRadius: 13, padding: 12, marginBottom: 10 },
    avatar: { width: 40, height: 40, borderRadius: 20, backgroundColor: c.surfaceAlt, alignItems: 'center', justifyContent: 'center' },
    avatarT: { fontSize: 13, fontWeight: '500', color: c.textSec },
    allow: { backgroundColor: c.brand, borderRadius: 9, paddingVertical: 8, paddingHorizontal: 14 },
    roleOpt: { flexDirection: 'row', alignItems: 'center', gap: 12, borderRadius: 14, padding: 15, marginBottom: 12 },
    pledge: { flexDirection: 'row', alignItems: 'flex-start', gap: 12, backgroundColor: c.card, borderWidth: 1, borderColor: c.border, borderRadius: 14, padding: 15, marginTop: 8 },
    check: { width: 24, height: 24, borderRadius: 7, alignItems: 'center', justifyContent: 'center' },
    doneCircle: { width: 80, height: 80, borderRadius: 40, backgroundColor: c.tint, alignItems: 'center', justifyContent: 'center', marginBottom: 20 },
    cta: { backgroundColor: c.brand, borderRadius: 13, padding: 15, alignItems: 'center' },
    ctaT: { color: '#fff', fontSize: 15, fontWeight: '500' },
  });
}
