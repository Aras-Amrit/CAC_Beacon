import React, { useEffect, useMemo, useRef, useState } from 'react';
import { View, Text, TouchableOpacity, FlatList, StyleSheet, ActivityIndicator, Image, Animated, PanResponder } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../ThemeContext';
import { listBuildings, deleteBuilding, API_URL } from '../net';
import { BUILTIN_BUILDINGS } from '../builtins';
import { getSavedBuildings, removeSavedBuilding } from '../storage';

// A row you can swipe left to delete (no visible button — judges won't see it).
function SwipeRow({ children, onDelete, onPress, colors }) {
  const tx = useRef(new Animated.Value(0)).current;
  const moved = useRef(false);
  const pan = useRef(
    PanResponder.create({
      // Claim (capture) the gesture as soon as it's clearly horizontal, so the
      // list's vertical scroll doesn't steal it.
      onMoveShouldSetPanResponderCapture: (_, g) => Math.abs(g.dx) > 8 && Math.abs(g.dx) > Math.abs(g.dy) * 1.2,
      onPanResponderGrant: () => { moved.current = false; },
      onPanResponderMove: (_, g) => { if (g.dx < 0) { moved.current = true; tx.setValue(Math.max(-160, g.dx)); } },
      onPanResponderRelease: (_, g) => {
        if (g.dx < -70) {
          onDelete && onDelete();
          Animated.timing(tx, { toValue: -600, duration: 160, useNativeDriver: true }).start();
        } else {
          Animated.spring(tx, { toValue: 0, useNativeDriver: true }).start();
        }
      },
      onPanResponderTerminate: () => { Animated.spring(tx, { toValue: 0, useNativeDriver: true }).start(); },
    })
  ).current;
  return (
    <View>
      <View style={{ position: 'absolute', right: 0, top: 0, bottom: 10, width: 70, backgroundColor: colors.danger, borderRadius: 14, alignItems: 'center', justifyContent: 'center' }}>
        <Ionicons name="trash-outline" size={20} color="#fff" />
      </View>
      <Animated.View style={{ transform: [{ translateX: tx }] }} {...pan.panHandlers}>
        <TouchableOpacity activeOpacity={0.85} onPress={() => { if (!moved.current) onPress && onPress(); }}>
          {children}
        </TouchableOpacity>
      </Animated.View>
    </View>
  );
}

export default function BuildingSelect({ navigation, route }) {
  const { colors } = useTheme();
  const s = useMemo(() => makeStyles(colors), [colors]);
  const [items, setItems] = useState(null);
  const onPick = route.params?.onPick;

  // List = built-ins + locally saved + server (if reachable). De-dup by id.
  const refresh = async () => {
    const saved = await getSavedBuildings();
    let server = [];
    // Fail fast when the server is off so built-ins/saved show instantly
    // (otherwise the fetch hangs ~75s waiting on the OS timeout).
    try {
      server = await Promise.race([
        listBuildings(),
        new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), 2000)),
      ]);
    } catch (e) { server = []; }
    const seen = new Set();
    const merged = [...BUILTIN_BUILDINGS, ...saved, ...server].filter((b) => {
      if (seen.has(b.id)) return false; seen.add(b.id); return true;
    });
    setItems(merged);
  };
  useEffect(() => {
    const unsub = navigation.addListener('focus', refresh);
    refresh();
    return unsub;
  }, [navigation]);

  const pick = (b) => { onPick && onPick(b); if (navigation.canGoBack()) navigation.goBack(); };

  const doDelete = async (b) => {
    setItems((prev) => (prev || []).filter((x) => x.id !== b.id));
    try { await removeSavedBuilding(b.id); } catch (e) {}
    if (!b.builtin) { try { await deleteBuilding(b.id); } catch (e) {} }
  };

  const thumbUri = (item) => item.localBlueprint ? item.localBlueprint : `${API_URL}/buildings/${item.id}/blueprint`;

  return (
    <View style={s.wrap}>
      <Text style={s.h1}>Which building are you in?</Text>
      <Text style={s.sub}>Pick one others have already scanned, or add a new one.</Text>
      {items === null ? (
        <ActivityIndicator color={colors.brand} style={{ marginTop: 30 }} />
      ) : (
        <FlatList
          data={items}
          keyExtractor={(b) => b.id}
          contentContainerStyle={{ paddingBottom: 90 }}
          ListEmptyComponent={<Text style={s.empty}>No buildings yet. Add the first one.</Text>}
          renderItem={({ item }) => (
            <SwipeRow colors={colors} onPress={() => pick(item)} onDelete={() => doDelete(item)}>
              <View style={s.row}>
                <View style={s.thumb}>
                  {item.blueprint
                    ? <Image source={{ uri: thumbUri(item) }} style={{ width: '100%', height: '100%' }} />
                    : <Ionicons name="business-outline" size={22} color={colors.brandDark} />}
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={s.name}>{item.name}</Text>
                  <Text style={s.addr}>{item.address || 'No address'}</Text>
                  <Text style={s.scans}>
                    <Ionicons name={item.blueprint ? 'document-attach-outline' : 'map-outline'} size={11} color={colors.muted} />
                    {' '}{item.blueprint ? 'Floor plan available' : 'Map only'}{(() => { const n = (item.exits?.length || 0) + (item.mapExits?.length || 0); return n ? ` · ${n} exits` : ''; })()} · {item.scans} scan{item.scans === 1 ? '' : 's'}
                  </Text>
                </View>
                <Ionicons name="chevron-forward" size={18} color={colors.iconMuted} />
              </View>
            </SwipeRow>
          )}
        />
      )}
      <TouchableOpacity style={s.addBtn} onPress={() => navigation.navigate('AddBuilding', { onPick, refresh })}>
        <Ionicons name="add" size={20} color="#fff" />
        <Text style={s.addT}>Scan a new building</Text>
      </TouchableOpacity>
    </View>
  );
}

function makeStyles(c) {
  return StyleSheet.create({
    wrap: { flex: 1, backgroundColor: c.surface, padding: 16, paddingTop: 24 },
    h1: { fontSize: 22, fontWeight: '500', color: c.ink },
    sub: { fontSize: 13, color: c.muted, marginTop: 4, marginBottom: 16 },
    empty: { textAlign: 'center', color: c.muted, marginTop: 40 },
    row: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: c.card, borderWidth: 1, borderColor: c.border, borderRadius: 14, padding: 12, marginBottom: 10 },
    thumb: { width: 48, height: 48, borderRadius: 10, backgroundColor: c.tint, alignItems: 'center', justifyContent: 'center', overflow: 'hidden' },
    name: { fontSize: 15, fontWeight: '500', color: c.ink },
    addr: { fontSize: 12, color: c.muted },
    scans: { fontSize: 11, color: c.muted, marginTop: 2 },
    addBtn: { position: 'absolute', bottom: 20, left: 16, right: 16, backgroundColor: c.brand, borderRadius: 13, padding: 15, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6 },
    addT: { color: '#fff', fontSize: 15, fontWeight: '500' },
  });
}
