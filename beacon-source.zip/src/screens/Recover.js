import React, { useEffect, useMemo, useRef, useState } from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet, Animated, Linking } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../ThemeContext';
const PHASES = ['Breathe in', 'Hold', 'Breathe out', 'Hold'];
export default function Recover() {
  const { colors } = useTheme();
  const s = useMemo(() => makeStyles(colors), [colors]);
  const [running, setRunning] = useState(false);
  const [label, setLabel] = useState('Breathe');
  const scale = useRef(new Animated.Value(1)).current;
  const timer = useRef(null);
  const phase = useRef(0);
  useEffect(() => () => clearInterval(timer.current), []);
  const step = () => {
    const p = phase.current % 4;
    setLabel(PHASES[p]);
    if (p === 0) Animated.timing(scale, { toValue: 1.4, duration: 4000, useNativeDriver: true }).start();
    if (p === 2) Animated.timing(scale, { toValue: 1, duration: 4000, useNativeDriver: true }).start();
    phase.current += 1;
  };
  const toggle = () => {
    if (running) { clearInterval(timer.current); setRunning(false); setLabel('Breathe'); Animated.timing(scale, { toValue: 1, duration: 300, useNativeDriver: true }).start(); }
    else { setRunning(true); phase.current = 0; step(); timer.current = setInterval(step, 4000); }
  };
  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.surface }} contentContainerStyle={{ padding: 16, alignItems: 'center' }}>
      <Text style={{ fontSize: 15, fontWeight: '500', color: colors.ink, marginTop: 4 }}>You're safe now. Let's slow down.</Text>
      <Text style={{ fontSize: 12, color: colors.muted, marginBottom: 16 }}>Follow the circle. In for 4, hold, out for 4.</Text>
      <View style={{ height: 200, justifyContent: 'center', alignItems: 'center' }}>
        <Animated.View style={[s.circle, { transform: [{ scale }] }]}>
          <Text style={{ color: colors.brandDark, fontSize: 14, fontWeight: '500' }}>{label}</Text>
        </Animated.View>
      </View>
      <TouchableOpacity style={s.startBtn} onPress={toggle}><Text style={{ color: '#fff', fontSize: 13, fontWeight: '500' }}>{running ? 'Stop' : 'Start'}</Text></TouchableOpacity>
      <View style={s.card}>
        <Text style={{ fontSize: 13, fontWeight: '500', color: colors.ink, marginBottom: 8 }}>Grounding · 5-4-3-2-1</Text>
        <Text style={{ fontSize: 12, color: colors.textSec, lineHeight: 20 }}>Name 5 things you see, 4 you can touch, 3 you hear, 2 you smell, 1 you taste.</Text>
      </View>
      <TouchableOpacity style={s.talkCard} onPress={() => Linking.openURL('tel:988')}>
        <Ionicons name="chatbubble-ellipses-outline" size={20} color={colors.people} />
        <View style={{ flex: 1, marginLeft: 10 }}>
          <Text style={{ fontSize: 13, fontWeight: '500', color: colors.ink }}>Talk to someone</Text>
          <Text style={{ fontSize: 11, color: colors.muted }}>Crisis line · community check-in</Text>
        </View>
        <Ionicons name="chevron-forward" size={18} color={colors.iconMuted} />
      </TouchableOpacity>
    </ScrollView>
  );
}
function makeStyles(c) {
  return StyleSheet.create({
    circle: { width: 120, height: 120, borderRadius: 60, backgroundColor: c.tint, borderWidth: 3, borderColor: c.brand, alignItems: 'center', justifyContent: 'center' },
    startBtn: { backgroundColor: c.brand, borderRadius: 11, paddingVertical: 10, paddingHorizontal: 22, marginTop: 8 },
    card: { alignSelf: 'stretch', backgroundColor: c.card, borderWidth: 1, borderColor: c.border, borderRadius: 14, padding: 14, marginTop: 16 },
    talkCard: { alignSelf: 'stretch', flexDirection: 'row', alignItems: 'center', backgroundColor: c.card, borderWidth: 1, borderColor: c.border, borderRadius: 14, padding: 13, marginTop: 10 },
  });
}
