import React, { useMemo, useState } from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../ThemeContext';
import { resetAll } from '../storage';

export default function Status({ navigation, role, building }) {
  const { colors } = useTheme();
  const s = useMemo(() => makeStyles(colors), [colors]);
  const responder = role === 'responder';
  const [me, setMe] = useState(null);

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.surface }} contentContainerStyle={{ padding: 16, paddingTop: 60 }}>
      <View style={s.headerRow}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 9 }}>
          <TouchableOpacity onLongPress={async () => { try { await resetAll(); } catch (e) {} require('react-native').DevSettings.reload(); }} delayLongPress={900}><TouchableOpacity onLongPress={async () => { try { await resetAll(); } catch (e) {} require('react-native').DevSettings.reload(); }} delayLongPress={900}><TouchableOpacity onLongPress={async () => { try { await resetAll(); } catch (e) {} require('react-native').DevSettings.reload(); }} delayLongPress={900}><View style={s.logo}><Ionicons name="radio-outline" size={18} color="#fff" /></View></TouchableOpacity></TouchableOpacity></TouchableOpacity>
          <View>
            <Text style={s.hTitle}>{responder ? 'Incident command' : 'Beacon'}</Text>
            <Text style={s.hSub}>{building?.name || 'No building'} {responder ? '· active response' : '· Floor 3'}</Text>
          </View>
        </View>
        <TouchableOpacity onPress={() => navigation.navigate('Settings')}><Ionicons name="settings-outline" size={21} color={colors.textSec} /></TouchableOpacity>
      </View>

      {responder ? (
        <View style={[s.card, { backgroundColor: colors.ink, borderColor: colors.ink }]}>
          <Text style={[s.eyebrow, { color: '#9AA7B1' }]}>INCIDENT COMMAND</Text>
          <Text style={{ fontSize: 19, fontWeight: '500', color: '#fff', marginVertical: 4 }}>19 safe · 3 SOS · 28 unknown</Text>
          <Text style={{ fontSize: 13, color: '#9AA7B1' }}>50 on floor 3 · <Text style={{ color: colors.responderAccent }}>tap a floor to see who's trapped</Text></Text>
        </View>
      ) : (
        <View style={[s.card, { backgroundColor: colors.cautionBg, borderColor: colors.cautionBorder }]}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <Text style={[s.eyebrow, { color: colors.cautionText }]}>CURRENT STATUS</Text>
            <Text style={{ fontSize: 11, color: colors.cautionText }}>12s ago</Text>
          </View>
          <Text style={{ fontSize: 25, fontWeight: '500', color: colors.cautionText, marginTop: 6 }}>Evacuate calmly</Text>
          <Text style={{ fontSize: 13, color: colors.cautionText2 }}>Earthquake M5.2 · 6 km away · aftershocks likely</Text>
          <View style={{ flexDirection: 'row', gap: 5, marginTop: 14 }}>
            {[colors.safe, colors.caution, colors.warning, colors.danger].map((cc, i) => (
              <View key={i} style={{ flex: 1, height: 7, borderRadius: 4, backgroundColor: cc, borderWidth: i === 2 ? 2 : 0, borderColor: colors.ink }} />
            ))}
          </View>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 5 }}>
            <Text style={s.scaleLbl}>Safe</Text><Text style={s.scaleLbl}>Caution</Text><Text style={s.scaleLbl}>Danger</Text>
          </View>
        </View>
      )}

      <View style={{ flexDirection: 'row', gap: 10, marginTop: 12 }}>
        <TouchableOpacity style={[s.bigBtn, { backgroundColor: me === 'safe' ? colors.brandDark : colors.safe }]} onPress={() => setMe('safe')}>
          <Ionicons name="checkmark" size={16} color="#fff" />
          <Text style={s.bigBtnT}>{me === 'safe' ? "You're safe" : "I'm safe"}</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[s.bigBtn, { backgroundColor: colors.danger }]} onPress={() => navigation.navigate('SOS')}>
          <Ionicons name="alert-circle" size={16} color="#fff" />
          <Text style={s.bigBtnT}>I need help</Text>
        </TouchableOpacity>
      </View>

      <TouchableOpacity style={s.exitCard} onPress={() => navigation.navigate('Map')}>
        <View style={s.exitIcon}><Ionicons name="exit-outline" size={21} color={colors.brandDark} /></View>
        <View style={{ flex: 1 }}>
          <Text style={s.rowTitle}>Nearest safe exit</Text>
          <Text style={s.rowSub}>Stairwell B · 35 m · route clear</Text>
        </View>
        <View style={s.guideBtn}><Text style={{ color: '#fff', fontWeight: '500', fontSize: 13 }}>Guide me</Text></View>
      </TouchableOpacity>

      <View style={{ flexDirection: 'row', gap: 10, marginTop: 12 }}>
        <View style={s.stat}><Text style={s.statN}>50</Text><Text style={s.rowSub}>people on this floor</Text></View>
        <View style={s.stat}><Text style={[s.statN, { color: colors.danger }]}>3</Text><Text style={s.rowSub}>need help nearby</Text></View>
      </View>

      <TouchableOpacity style={s.recoverCard} onPress={() => navigation.navigate('Recover')}>
        <Ionicons name="heart-outline" size={20} color={colors.brand} />
        <Text style={{ flex: 1, fontSize: 13, color: colors.ink, marginLeft: 10 }}>Feeling shaken? Take a moment in Recover.</Text>
        <Ionicons name="chevron-forward" size={18} color={colors.iconMuted} />
      </TouchableOpacity>
    </ScrollView>
  );
}

function makeStyles(c) {
  return StyleSheet.create({
    headerRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 },
    logo: { width: 30, height: 30, borderRadius: 9, backgroundColor: c.brand, alignItems: 'center', justifyContent: 'center' },
    hTitle: { fontSize: 16, fontWeight: '500', color: c.ink },
    hSub: { fontSize: 11, color: c.muted },
    card: { borderRadius: 16, padding: 18, borderWidth: 1 },
    eyebrow: { fontSize: 11, fontWeight: '500', letterSpacing: 1 },
    scaleLbl: { fontSize: 10, color: c.cautionText2 },
    bigBtn: { flex: 1, borderRadius: 13, padding: 13, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6 },
    bigBtnT: { color: '#fff', fontSize: 14, fontWeight: '500' },
    exitCard: { backgroundColor: c.card, borderWidth: 1, borderColor: c.border, borderRadius: 14, padding: 14, marginTop: 12, flexDirection: 'row', alignItems: 'center', gap: 12 },
    exitIcon: { width: 40, height: 40, borderRadius: 10, backgroundColor: c.tint, alignItems: 'center', justifyContent: 'center' },
    guideBtn: { backgroundColor: c.brand, borderRadius: 10, paddingVertical: 8, paddingHorizontal: 12 },
    rowTitle: { fontSize: 14, fontWeight: '500', color: c.ink },
    rowSub: { fontSize: 11, color: c.muted },
    stat: { flex: 1, backgroundColor: c.card, borderWidth: 1, borderColor: c.border, borderRadius: 14, padding: 13 },
    statN: { fontSize: 22, fontWeight: '500', color: c.ink },
    recoverCard: { flexDirection: 'row', alignItems: 'center', backgroundColor: c.card, borderWidth: 1, borderColor: c.border, borderRadius: 14, padding: 13, marginTop: 12 },
  });
}
