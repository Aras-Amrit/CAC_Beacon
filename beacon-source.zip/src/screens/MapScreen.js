import React, { useEffect, useMemo, useRef, useState } from 'react';
import { View, Text, StyleSheet, Platform, TouchableOpacity, Modal, Image, useWindowDimensions } from 'react-native';
import MapView, { Marker, Polyline, PROVIDER_GOOGLE } from 'react-native-maps';
import * as Location from 'expo-location';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../ThemeContext';
import { API_URL } from '../net';
import { crowdFor } from '../builtins';

const STATUS_COLOR = { safe: '#22A559', noresponse: '#E8B10A', help: '#E23B3B' };

function lerp(a, b, t) { return a + (b - a) * t; }
function dist(a, b) { const dx = a.latitude - b.latitude, dy = a.longitude - b.longitude; return Math.sqrt(dx*dx + dy*dy); }

export default function MapScreen({ building, role }) {
  const { colors } = useTheme();
  const s = useMemo(() => makeStyles(colors), [colors]);
  const { width } = useWindowDimensions();
  const [region, setRegion] = useState(null);
  const [showPlan, setShowPlan] = useState(false);
  const [animPos, setAnimPos] = useState(null);
  const timer = useRef(null);

  // A sample "you are here" point just inside the building, for the demo.
  const youCoord = building?.coord
    ? { latitude: building.coord.latitude - 0.00035, longitude: building.coord.longitude + 0.00045 }
    : null;

  const crowd = useMemo(() => (building?.coord ? crowdFor(building.coord) : []), [building?.id]);
  const exits = building?.mapExits || [];
  const planExits = building?.exits || [];

  // Nearest CLEAR exit to the sample you-position → animated escape path.
  const nearestExit = useMemo(() => {
    if (!youCoord) return null;
    const open = exits.filter((e) => e.status === 'clear');
    if (!open.length) return null;
    return open.reduce((best, e) => (dist(youCoord, e) < dist(youCoord, best) ? e : best), open[0]);
  }, [building?.id]);

  useEffect(() => {
    (async () => {
      try { await Location.requestForegroundPermissionsAsync(); } catch (e) {}
      const center = building?.coord || { latitude: 33.0458, longitude: -96.6989 };
      setRegion({ ...center, latitudeDelta: 0.0032, longitudeDelta: 0.0032 });
    })();
  }, [building?.id]);

  // Animate a dot traveling from you → nearest exit, looping.
  useEffect(() => {
    if (!youCoord || !nearestExit) { setAnimPos(null); return; }
    let t = 0;
    timer.current && clearInterval(timer.current);
    timer.current = setInterval(() => {
      t += 0.02; if (t > 1) t = 0;
      setAnimPos({
        latitude: lerp(youCoord.latitude, nearestExit.latitude, t),
        longitude: lerp(youCoord.longitude, nearestExit.longitude, t),
      });
    }, 55);
    return () => timer.current && clearInterval(timer.current);
  }, [building?.id]);

  const aspect = building?.imgW && building?.imgH ? building.imgW / building.imgH : 1;
  const planW = width * 0.92, planH = planW / aspect;
  const planUri = building?.localBlueprint ? building.localBlueprint : `${API_URL}/buildings/${building?.id}/blueprint`;
  const blockedPlan = planExits.filter((e) => e.status === 'blocked').length;

  const helpCount = crowd.filter((p) => p.status === 'help').length;

  return (
    <View style={{ flex: 1, backgroundColor: colors.surface }}>
      {region && (
        <MapView style={{ flex: 1 }} provider={Platform.OS === 'android' ? PROVIDER_GOOGLE : undefined}
          initialRegion={region} userInterfaceStyle={colors.mode}>

          {/* Escape path to nearest clear exit */}
          {youCoord && nearestExit && (
            <Polyline coordinates={[youCoord, nearestExit]} strokeColor="#0E9F8B" strokeWidth={4} lineDashPattern={[10, 8]} />
          )}
          {animPos && (
            <Marker coordinate={animPos} anchor={{ x: 0.5, y: 0.5 }} tracksViewChanges={false}>
              <View style={s.travelDot} />
            </Marker>
          )}

          {/* 50-person crowd */}
          {crowd.map((p) => (
            <Marker key={p.id} coordinate={p.coord} anchor={{ x: 0.5, y: 0.5 }} tracksViewChanges={false}>
              <View style={{ alignItems: 'center' }}>
                <View style={[s.person, { backgroundColor: STATUS_COLOR[p.status] }]} />
                {p.status !== 'safe' && <Text style={[s.personLbl, { color: STATUS_COLOR[p.status] }]}>{p.name}</Text>}
              </View>
            </Marker>
          ))}

          {/* Exit pins */}
          {exits.map((ex, i) => (
            <Marker key={'ex' + i} coordinate={{ latitude: ex.latitude, longitude: ex.longitude }} anchor={{ x: 0.5, y: 0.5 }} tracksViewChanges={false}
              title={ex.status === 'clear' ? 'Exit — clear' : 'Exit — blocked'}>
              <View style={[s.exitMapPin, { backgroundColor: ex.status === 'clear' ? colors.safe : colors.danger }]}>
                <Ionicons name={ex.status === 'clear' ? 'exit-outline' : 'close'} size={14} color="#fff" />
              </View>
            </Marker>
          ))}

          {/* Your location — large blue dot with halo */}
          {youCoord && (
            <Marker coordinate={youCoord} anchor={{ x: 0.5, y: 0.5 }} tracksViewChanges={false}>
              <View style={s.youHalo}><View style={s.youDot} /></View>
            </Marker>
          )}
        </MapView>
      )}

      <View style={s.topBar}>
        <View style={s.pill}>
          <Ionicons name="business-outline" size={14} color={colors.brandDark} />
          <Text style={s.pillT}>{building?.name || 'No building'}</Text>
        </View>
        <Text style={s.count}>{crowd.length} people · {helpCount} need help</Text>
      </View>

      {building?.blueprint && (
        <TouchableOpacity style={s.planBtn} onPress={() => setShowPlan(true)}>
          <Ionicons name="map-outline" size={16} color="#fff" />
          <Text style={s.planT}>Floor plan{planExits.length ? ` · ${planExits.length} exits` : ''}</Text>
        </TouchableOpacity>
      )}

      {youCoord && nearestExit && (
        <View style={s.exitBanner}>
          <Ionicons name="walk" size={18} color={colors.brandDark} />
          <Text style={s.exitBannerT}>Nearest clear exit — follow the path</Text>
        </View>
      )}

      <View style={s.legend}>
        <Legend c="#2563EB" label="You" colors={colors} />
        <Legend c="#22A559" label="Safe" colors={colors} />
        <Legend c="#E8B10A" label="No response" colors={colors} />
        <Legend c="#E23B3B" label="Needs help" colors={colors} />
      </View>

      <Modal visible={showPlan} transparent animationType="fade" onRequestClose={() => setShowPlan(false)}>
        <View style={s.modal}>
          <View style={{ width: planW }}>
            <View style={{ marginBottom: 10 }}>
              <Text style={s.planTitle}>{building?.name} · floor plan</Text>
              <Text style={s.planMeta}>{planExits.length} exit{planExits.length === 1 ? '' : 's'}{blockedPlan ? ` · ${blockedPlan} blocked` : ' · all clear'}</Text>
            </View>
            <View style={{ width: planW, height: planH, borderRadius: 12, overflow: 'hidden', backgroundColor: '#fff' }}>
              <Image source={{ uri: planUri }} style={{ width: '100%', height: '100%' }} resizeMode="cover" />
              {planExits.map((ex, i) => (
                <View key={i} style={[s.exitPin, { left: ex.x * planW - 14, top: ex.y * planH - 14, backgroundColor: ex.status === 'clear' ? colors.safe : colors.danger }]}>
                  <Ionicons name={ex.status === 'clear' ? 'exit-outline' : 'close'} size={15} color="#fff" />
                </View>
              ))}
            </View>
            <View style={s.planLegend}>
              <Legend c={colors.safe} label="Clear exit" colors={{ textSec: '#fff' }} />
              <Legend c={colors.danger} label="Blocked" colors={{ textSec: '#fff' }} />
            </View>
            <TouchableOpacity style={s.closeBtn} onPress={() => setShowPlan(false)}>
              <Text style={{ color: '#fff', fontWeight: '500' }}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const Legend = ({ c, label, colors }) => (
  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}>
    <View style={{ width: 10, height: 10, borderRadius: 5, backgroundColor: c }} />
    <Text style={{ fontSize: 11, color: colors.textSec }}>{label}</Text>
  </View>
);

function makeStyles(c) {
  return StyleSheet.create({
    person: { width: 11, height: 11, borderRadius: 6, borderWidth: 1.5, borderColor: '#fff' },
    personLbl: { fontSize: 9, fontWeight: '600', marginTop: 1, textShadowColor: 'rgba(255,255,255,0.9)', textShadowRadius: 2 },
    exitMapPin: { width: 26, height: 26, borderRadius: 13, alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: '#fff' },
    youHalo: { width: 34, height: 34, borderRadius: 17, backgroundColor: 'rgba(37,99,235,0.25)', alignItems: 'center', justifyContent: 'center' },
    youDot: { width: 18, height: 18, borderRadius: 9, backgroundColor: '#2563EB', borderWidth: 3, borderColor: '#fff' },
    travelDot: { width: 13, height: 13, borderRadius: 7, backgroundColor: '#0E9F8B', borderWidth: 2, borderColor: '#fff' },
    topBar: { position: 'absolute', top: 12, left: 12, right: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
    pill: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: c.card, borderRadius: 999, paddingVertical: 7, paddingHorizontal: 12, borderWidth: 1, borderColor: c.border },
    pillT: { fontSize: 13, fontWeight: '500', color: c.ink },
    count: { fontSize: 12, color: c.ink, backgroundColor: c.card, borderRadius: 999, paddingVertical: 7, paddingHorizontal: 12, borderWidth: 1, borderColor: c.border, overflow: 'hidden' },
    planBtn: { position: 'absolute', bottom: 92, right: 12, backgroundColor: c.brand, borderRadius: 999, flexDirection: 'row', alignItems: 'center', gap: 6, paddingVertical: 10, paddingHorizontal: 14 },
    planT: { color: '#fff', fontWeight: '500', fontSize: 13 },
    exitBanner: { position: 'absolute', bottom: 52, left: 12, right: 12, backgroundColor: c.tint, borderRadius: 12, padding: 10, flexDirection: 'row', alignItems: 'center', gap: 8 },
    exitBannerT: { fontSize: 12, color: c.brandDark, fontWeight: '500' },
    legend: { position: 'absolute', bottom: 12, left: 12, backgroundColor: c.card, borderRadius: 10, paddingVertical: 8, paddingHorizontal: 10, flexDirection: 'row', flexWrap: 'wrap', gap: 10, borderWidth: 1, borderColor: c.border, maxWidth: 260 },
    modal: { flex: 1, backgroundColor: 'rgba(0,0,0,0.9)', alignItems: 'center', justifyContent: 'center' },
    planTitle: { color: '#fff', fontSize: 16, fontWeight: '500' },
    planMeta: { color: '#B8C0C8', fontSize: 12, marginTop: 2 },
    exitPin: { position: 'absolute', width: 28, height: 28, borderRadius: 14, alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: '#fff' },
    planLegend: { flexDirection: 'row', gap: 16, marginTop: 12, justifyContent: 'center' },
    closeBtn: { marginTop: 16, backgroundColor: c.brand, borderRadius: 10, paddingVertical: 10, alignItems: 'center' },
  });
}
