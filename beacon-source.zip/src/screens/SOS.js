import React, { useMemo } from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet, Linking, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../ThemeContext';

export default function SOS({ role }) {
  const { colors } = useTheme();
  const s = useMemo(() => makeStyles(colors), [colors]);

  if (role === 'responder') return <ResponderOps s={s} colors={colors} />;

  const call911 = () => {
    Alert.alert('Call 911?', 'This will place a real call to emergency services.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Call', style: 'destructive', onPress: () => Linking.openURL('tel:911') },
    ]);
  };
  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.surface }} contentContainerStyle={{ padding: 16, alignItems: 'center' }}>
      <Text style={{ fontSize: 13, color: colors.muted, textAlign: 'center', marginVertical: 10 }}>Alert emergency services and share your live location.</Text>
      <TouchableOpacity style={s.sosBtn} onPress={call911}>
        <Ionicons name="call" size={34} color="#fff" />
        <Text style={{ color: '#fff', fontSize: 19, fontWeight: '500', marginTop: 4 }}>Call 911</Text>
      </TouchableOpacity>
      <View style={s.grid}>
        <Quick s={s} colors={colors} icon="shield-outline" color={colors.brand} title="Building security" sub="ext. 4400" onPress={() => Linking.openURL('tel:+14695554400')} />
        <Quick s={s} colors={colors} icon="heart-outline" color={colors.danger} title="Emergency contact" sub="Mom · call" onPress={() => Linking.openURL('tel:+14695550134')} />
        <Quick s={s} colors={colors} icon="flame-outline" color={colors.warning} title="Fire dept" sub="direct line" onPress={() => Linking.openURL('tel:911')} />
        <Quick s={s} colors={colors} icon="radio-outline" color={colors.people} title="SOS broadcast" sub="alert people near you" onPress={() => Alert.alert('SOS broadcast sent', 'People and responders near you have been notified with your location.')} />
      </View>
      <View style={s.share}>
        <Ionicons name="location-outline" size={19} color={colors.brandDark} />
        <Text style={{ fontSize: 12, color: colors.brandDark, flex: 1, marginLeft: 9 }}>Live location sharing with responders</Text>
        <View style={s.toggleOn}><View style={s.knob} /></View>
      </View>
    </ScrollView>
  );
}

// First responders ARE 911 — they get dispatch/coordination actions instead.
function ResponderOps({ s, colors }) {
  const act = (title, msg) => Alert.alert(title, msg);
  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.surface }} contentContainerStyle={{ padding: 16 }}>
      <Text style={s.opsTitle}>Dispatch</Text>
      <Text style={s.opsSub}>Coordinate the response on site.</Text>

      <TouchableOpacity style={[s.opsBig, { backgroundColor: colors.danger }]} onPress={() => act('Backup requested', 'Additional units and medical have been dispatched to your location.')}>
        <Ionicons name="megaphone" size={30} color="#fff" />
        <Text style={s.opsBigT}>Request backup</Text>
        <Text style={s.opsBigS}>Units + medical to your position</Text>
      </TouchableOpacity>

      <View style={s.opsGrid}>
        <Op s={s} colors={colors} icon="radio" color={colors.people} title="Radio dispatch" sub="Open channel" onPress={() => act('Channel open', 'Connected to incident command on channel 1.')} />
        <Op s={s} colors={colors} icon="medkit" color={colors.danger} title="Request medical" sub="EMS to zone" onPress={() => act('Medical requested', 'EMS routed to the marked urgent cases.')} />
        <Op s={s} colors={colors} icon="shield-checkmark" color={colors.safe} title="Mark area cleared" sub="This zone safe" onPress={() => act('Zone cleared', 'This area has been marked cleared on the incident map.')} />
        <Op s={s} colors={colors} icon="people" color={colors.warning} title="Headcount" sub="Request status" onPress={() => act('Headcount requested', 'All units asked to report their zone status.')} />
      </View>

      <View style={s.share}>
        <Ionicons name="navigate" size={19} color={colors.brandDark} />
        <Text style={{ fontSize: 12, color: colors.brandDark, flex: 1, marginLeft: 9 }}>Broadcasting your position to all units</Text>
        <View style={s.toggleOn}><View style={s.knob} /></View>
      </View>
    </ScrollView>
  );
}

const Quick = ({ s, colors, icon, color, title, sub, onPress }) => (
  <TouchableOpacity style={s.qc} onPress={onPress}>
    <Ionicons name={icon} size={20} color={color} />
    <Text style={{ fontSize: 13, fontWeight: '500', color: colors.ink, marginTop: 5 }}>{title}</Text>
    <Text style={{ fontSize: 11, color: colors.muted }}>{sub}</Text>
  </TouchableOpacity>
);
const Op = ({ s, colors, icon, color, title, sub, onPress }) => (
  <TouchableOpacity style={s.qc} onPress={onPress}>
    <Ionicons name={icon} size={20} color={color} />
    <Text style={{ fontSize: 13, fontWeight: '500', color: colors.ink, marginTop: 5 }}>{title}</Text>
    <Text style={{ fontSize: 11, color: colors.muted }}>{sub}</Text>
  </TouchableOpacity>
);

function makeStyles(c) {
  return StyleSheet.create({
    sosBtn: { width: 150, height: 150, borderRadius: 75, backgroundColor: c.danger, alignItems: 'center', justifyContent: 'center' },
    grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginTop: 20 },
    qc: { width: '47%', backgroundColor: c.card, borderWidth: 1, borderColor: c.border, borderRadius: 13, padding: 13 },
    share: { flexDirection: 'row', alignItems: 'center', backgroundColor: c.tint, borderRadius: 12, padding: 11, marginTop: 14 },
    toggleOn: { width: 38, height: 22, borderRadius: 11, backgroundColor: c.brand, justifyContent: 'center', alignItems: 'flex-end', paddingRight: 2 },
    knob: { width: 18, height: 18, borderRadius: 9, backgroundColor: '#fff' },
    opsTitle: { fontSize: 20, fontWeight: '500', color: c.ink },
    opsSub: { fontSize: 12, color: c.muted, marginTop: 3, marginBottom: 14 },
    opsBig: { borderRadius: 16, padding: 18, alignItems: 'center' },
    opsBigT: { color: '#fff', fontSize: 18, fontWeight: '500', marginTop: 6 },
    opsBigS: { color: 'rgba(255,255,255,0.85)', fontSize: 12, marginTop: 2 },
    opsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginTop: 14 },
  });
}
