import React, { useMemo, useState } from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet, Switch } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../ThemeContext';

export default function Settings({ navigation, role, setRole, building, onChangeBuilding }) {
  const { colors, dark, toggle } = useTheme();
  const s = useMemo(() => makeStyles(colors), [colors]);
  const responder = role === 'responder';
  const [honest, setHonest] = useState(true);
  const [locOn, setLocOn] = useState(true);
  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.surface }} contentContainerStyle={{ padding: 16 }}>
      <View style={s.card}>
        <Text style={s.label}>I am a</Text>
        <View style={{ flexDirection: 'row', gap: 8 }}>
          <TouchableOpacity style={[s.roleBtn, { backgroundColor: !responder ? colors.ink : colors.surfaceAlt }]} onPress={() => setRole('community')}>
            <Text style={{ color: !responder ? '#fff' : colors.textSec, fontWeight: '500', fontSize: 13 }}>Community member</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[s.roleBtn, { backgroundColor: responder ? colors.ink : colors.surfaceAlt }]} onPress={() => setRole('responder')}>
            <Text style={{ color: responder ? '#fff' : colors.textSec, fontWeight: '500', fontSize: 13 }}>First responder</Text>
          </TouchableOpacity>
        </View>
      </View>
      <View style={[s.card, { padding: 0 }]}>
        <Rowt s={s} colors={colors} icon="business-outline" iconColor={colors.brand} title="Current building" desc={building?.name || 'None selected'} onPress={onChangeBuilding} right={<Ionicons name="chevron-forward" size={18} color={colors.iconMuted} />} border />
        <Rowt s={s} colors={colors} icon="moon-outline" iconColor={colors.people} title="Dark mode" desc="Match your surroundings at night" right={<Switch value={dark} onValueChange={toggle} trackColor={{ true: colors.brand }} />} border />
        <Rowt s={s} colors={colors} icon="shield-checkmark-outline" iconColor={colors.brand} title="Honest reporting" desc="Only mark yourself safe if you truly are. Rescuers count on it." right={<Switch value={honest} onValueChange={setHonest} trackColor={{ true: colors.brand }} />} border />
        <Rowt s={s} colors={colors} icon="location-outline" iconColor={colors.people} title="Location during emergencies" desc="Always on when an alert is active" right={<Switch value={locOn} onValueChange={setLocOn} trackColor={{ true: colors.brand }} />} border />
        <Rowt s={s} colors={colors} icon="medkit-outline" iconColor={colors.danger} title="Medical info" desc="Blood type, allergies for responders" right={<Ionicons name="chevron-forward" size={18} color={colors.iconMuted} />} />
      </View>
    </ScrollView>
  );
}
const Rowt = ({ s, colors, icon, iconColor, title, desc, right, border, onPress }) => (
  <TouchableOpacity disabled={!onPress} onPress={onPress} style={[s.rowt, border && { borderBottomWidth: 1, borderBottomColor: colors.border }]}>
    <Ionicons name={icon} size={20} color={iconColor} />
    <View style={{ flex: 1, marginHorizontal: 11 }}>
      <Text style={{ fontSize: 13, fontWeight: '500', color: colors.ink }}>{title}</Text>
      <Text style={{ fontSize: 11, color: colors.muted }}>{desc}</Text>
    </View>
    {right}
  </TouchableOpacity>
);
function makeStyles(c) {
  return StyleSheet.create({
    card: { backgroundColor: c.card, borderWidth: 1, borderColor: c.border, borderRadius: 14, padding: 14, marginBottom: 12, overflow: 'hidden' },
    label: { fontSize: 12, color: c.muted, marginBottom: 9 },
    roleBtn: { flex: 1, borderRadius: 10, padding: 11, alignItems: 'center' },
    rowt: { flexDirection: 'row', alignItems: 'center', padding: 14 },
  });
}
