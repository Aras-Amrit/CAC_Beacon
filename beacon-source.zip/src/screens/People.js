import React, { useMemo, useState } from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../ThemeContext';
import { circle, statusMeta } from '../data';
import { crowdFor } from '../builtins';

// Responder triage states, in cycle order.
const TRI = {
  unseen:   { label: 'Not seen', color: '#8A97A2', icon: 'help' },
  needshelp:{ label: 'Needs help', color: '#E8792B', icon: 'alert-circle' },
  urgent:   { label: 'Urgent', color: '#E23B3B', icon: 'warning' },
  rescued:  { label: 'Rescued', color: '#22A559', icon: 'checkmark-circle' },
};
const CYCLE = ['unseen', 'needshelp', 'urgent'];

export default function People({ navigation, role, building }) {
  const { colors } = useTheme();
  const s = useMemo(() => makeStyles(colors), [colors]);

  if (role === 'responder') return <Triage s={s} colors={colors} building={building} />;

  // Community: your circle
  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.surface }} contentContainerStyle={{ padding: 16 }}>
      <View style={s.seg}>
        <View style={[s.segItem, { backgroundColor: colors.card }]}><Text style={{ fontWeight: '500', color: colors.ink, fontSize: 12 }}>My circle</Text></View>
        <View style={s.segItem}><Text style={{ color: colors.textSec, fontSize: 12 }}>Building</Text></View>
      </View>
      {circle.map((p) => {
        const m = statusMeta[p.status];
        return (
          <TouchableOpacity key={p.id} style={s.row} onPress={() => navigation.navigate('PersonDetail', { id: p.id })}>
            <View style={s.avatar}><Text style={s.avatarT}>{p.initials}</Text></View>
            <View style={{ flex: 1 }}>
              <Text style={s.name}>{p.name}</Text>
              <Text style={s.where}>{p.where}</Text>
            </View>
            <View style={[s.chip, { backgroundColor: m.color + '22' }]}><Text style={{ fontSize: 11, fontWeight: '500', color: m.color }}>{m.label}</Text></View>
            <Ionicons name="chevron-forward" size={18} color={colors.iconMuted} />
          </TouchableOpacity>
        );
      })}
    </ScrollView>
  );
}

function Triage({ s, colors, building }) {
  const base = useMemo(() => {
    const c = building?.coord ? crowdFor(building.coord) : [];
    return c.map((p, i) => ({
      id: p.id, name: p.name,
      zone: ['Main hall', 'West wing', 'East wing', 'Lobby', 'Balcony', 'Concourse'][i % 6],
      init: p.status === 'help' ? 'urgent' : p.status === 'noresponse' ? 'needshelp' : 'unseen',
    }));
  }, [building?.id]);

  const [st, setSt] = useState({});
  const statusOf = (p) => st[p.id] || p.init;
  const cycle = (p) => setSt((x) => {
    const cur = statusOf(p);
    if (cur === 'rescued') return { ...x, [p.id]: 'unseen' };
    const i = CYCLE.indexOf(cur);
    return { ...x, [p.id]: CYCLE[(i + 1) % CYCLE.length] };
  });
  const rescue = (p) => setSt((x) => ({ ...x, [p.id]: statusOf(p) === 'rescued' ? 'unseen' : 'rescued' }));

  const counts = base.reduce((a, p) => { const k = statusOf(p); a[k] = (a[k] || 0) + 1; return a; }, {});
  const order = { urgent: 0, needshelp: 1, unseen: 2, rescued: 3 };
  const sorted = [...base].sort((a, b) => order[statusOf(a)] - order[statusOf(b)]);

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.surface }} contentContainerStyle={{ padding: 16 }}>
      <Text style={s.triTitle}>People in area</Text>
      <Text style={s.triSub}>Everyone detected in {building?.name || 'this building'} — tap to triage.</Text>

      <View style={s.statRow}>
        <Stat s={s} n={counts.urgent || 0} label="Urgent" color={TRI.urgent.color} />
        <Stat s={s} n={counts.needshelp || 0} label="Needs help" color={TRI.needshelp.color} />
        <Stat s={s} n={counts.unseen || 0} label="Not seen" color={TRI.unseen.color} />
        <Stat s={s} n={counts.rescued || 0} label="Rescued" color={TRI.rescued.color} />
      </View>

      {sorted.map((p) => {
        const t = TRI[statusOf(p)];
        const rescued = statusOf(p) === 'rescued';
        return (
          <View key={p.id} style={[s.trow, rescued && { opacity: 0.6 }]}>
            <View style={[s.dot, { backgroundColor: t.color }]} />
            <View style={{ flex: 1 }}>
              <Text style={s.tname}>{p.name}</Text>
              <Text style={s.tzone}>{p.zone}</Text>
            </View>
            <TouchableOpacity style={[s.priChip, { backgroundColor: t.color + '22' }]} onPress={() => cycle(p)}>
              <Ionicons name={t.icon} size={13} color={t.color} />
              <Text style={{ fontSize: 11, fontWeight: '500', color: t.color }}>{t.label}</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[s.resBtn, rescued && { backgroundColor: TRI.rescued.color }]} onPress={() => rescue(p)}>
              <Ionicons name="checkmark" size={18} color={rescued ? '#fff' : colors.iconMuted} />
            </TouchableOpacity>
          </View>
        );
      })}
    </ScrollView>
  );
}

const Stat = ({ s, n, label, color }) => (
  <View style={s.stat}>
    <Text style={[s.statN, { color }]}>{n}</Text>
    <Text style={s.statL}>{label}</Text>
  </View>
);

function makeStyles(c) {
  return StyleSheet.create({
    seg: { flexDirection: 'row', alignSelf: 'flex-start', backgroundColor: c.surfaceAlt, borderRadius: 999, padding: 3, marginBottom: 12 },
    segItem: { paddingVertical: 5, paddingHorizontal: 14, borderRadius: 999 },
    row: { flexDirection: 'row', alignItems: 'center', gap: 11, backgroundColor: c.card, borderWidth: 1, borderColor: c.border, borderRadius: 13, padding: 12, marginBottom: 9 },
    avatar: { width: 40, height: 40, borderRadius: 20, backgroundColor: c.surfaceAlt, alignItems: 'center', justifyContent: 'center' },
    avatarT: { fontSize: 13, fontWeight: '500', color: c.textSec },
    name: { fontSize: 14, fontWeight: '500', color: c.ink },
    where: { fontSize: 11, color: c.muted },
    chip: { paddingVertical: 4, paddingHorizontal: 9, borderRadius: 999 },
    triTitle: { fontSize: 20, fontWeight: '500', color: c.ink },
    triSub: { fontSize: 12, color: c.muted, marginTop: 3, marginBottom: 14 },
    statRow: { flexDirection: 'row', gap: 8, marginBottom: 14 },
    stat: { flex: 1, backgroundColor: c.card, borderWidth: 1, borderColor: c.border, borderRadius: 12, paddingVertical: 10, alignItems: 'center' },
    statN: { fontSize: 20, fontWeight: '500' },
    statL: { fontSize: 10, color: c.muted, marginTop: 2 },
    trow: { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: c.card, borderWidth: 1, borderColor: c.border, borderRadius: 12, padding: 11, marginBottom: 8 },
    dot: { width: 10, height: 10, borderRadius: 5 },
    tname: { fontSize: 14, fontWeight: '500', color: c.ink },
    tzone: { fontSize: 11, color: c.muted },
    priChip: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingVertical: 5, paddingHorizontal: 9, borderRadius: 999 },
    resBtn: { width: 34, height: 34, borderRadius: 9, backgroundColor: c.surfaceAlt, alignItems: 'center', justifyContent: 'center' },
  });
}
