import React, { useMemo, useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Image, Alert, ActivityIndicator, Pressable, ScrollView, Platform } from 'react-native';
import MapView, { Marker, PROVIDER_GOOGLE } from 'react-native-maps';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import * as Location from 'expo-location';
import { useTheme } from '../ThemeContext';
import { addBuilding } from '../net';
import { matchPreset } from '../builtins';
import { addSavedBuilding } from '../storage';

const MODES = [
  { key: 'satellite', label: 'Satellite', icon: 'earth' },
  { key: 'standard', label: 'Standard', icon: 'map' },
  { key: 'photo', label: 'Photo', icon: 'image' },
];

export default function AddBuilding({ navigation, route }) {
  const { colors } = useTheme();
  const s = useMemo(() => makeStyles(colors), [colors]);
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [region, setRegion] = useState(null);
  const [mode, setMode] = useState('satellite');
  const [mapExits, setMapExits] = useState([]);
  const [locating, setLocating] = useState(false);
  const [photo, setPhoto] = useState(null);   // { uri, base64, w, h }
  const [exits, setExits] = useState([]);      // photo exits
  const [box, setBox] = useState({ w: 0, h: 0 });
  const [preset, setPreset] = useState(null);  // locked preset building, if matched
  const [saving, setSaving] = useState(false);

  // Find: first check presets (Costco, etc). If matched, load its coords,
  // floor plan and exits directly — no geocoding, fully hardcoded for the demo.
  const findOnMap = async () => {
    const hit = matchPreset(name + ' ' + address);
    if (hit) {
      setPreset(hit);
      setName((n) => n || hit.name);
      setAddress((a) => a || hit.address);
      setRegion({ ...hit.coord, latitudeDelta: 0.003, longitudeDelta: 0.003 });
      setMapExits(hit.mapExits || []);
      setExits(hit.exits || []);
      setPhoto({ uri: hit.localBlueprint, base64: hit.localBlueprint, w: hit.imgW, h: hit.imgH });
      return;
    }
    if (!address.trim()) return Alert.alert('Enter an address', 'Type the building address first.');
    setLocating(true);
    try {
      const res = await Location.geocodeAsync(address.trim());
      if (!res.length) { Alert.alert('Not found', "Couldn't find that address. Try adding city and state."); return; }
      setRegion({ latitude: res[0].latitude, longitude: res[0].longitude, latitudeDelta: 0.0012, longitudeDelta: 0.0012 });
    } catch (e) { Alert.alert('Lookup failed', 'Could not look up that address.'); }
    finally { setLocating(false); }
  };

  const addMapExit = (coord) => { if (!preset) setMapExits((p) => [...p, { ...coord, status: 'clear' }]); };
  const cycleMapExit = (i) => setMapExits((prev) => {
    const ex = prev[i];
    if (ex.status === 'clear') return prev.map((e, idx) => idx === i ? { ...e, status: 'blocked' } : e);
    return prev.filter((_, idx) => idx !== i);
  });

  const capture = async (fromCamera) => {
    if (preset) return; // preset floor plan is fixed
    const opts = { base64: true, quality: 0.5, allowsEditing: true };
    const perm = fromCamera ? await ImagePicker.requestCameraPermissionsAsync() : await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!perm.granted) return Alert.alert('Permission needed', 'Allow camera/photos to add a floor plan.');
    const r = fromCamera ? await ImagePicker.launchCameraAsync(opts) : await ImagePicker.launchImageLibraryAsync(opts);
    if (!r.canceled) { const a = r.assets[0]; setPhoto({ uri: a.uri, base64: `data:image/jpeg;base64,${a.base64}`, w: a.width, h: a.height }); setExits([]); }
  };
  const addExit = (e) => {
    if (preset || !box.w) return;
    const x = Math.min(1, Math.max(0, e.nativeEvent.locationX / box.w));
    const y = Math.min(1, Math.max(0, e.nativeEvent.locationY / box.h));
    setExits((prev) => [...prev, { x, y, status: 'clear' }]);
  };
  const toggleExit = (i) => { if (!preset) setExits((prev) => prev.map((ex, idx) => idx === i ? { ...ex, status: ex.status === 'clear' ? 'blocked' : 'clear' } : ex)); };
  const removeExit = (i) => { if (!preset) setExits((prev) => prev.filter((_, idx) => idx !== i)); };

  const aspect = photo && photo.w && photo.h ? photo.w / photo.h : 1;
  const mapBlocked = mapExits.filter((e) => e.status === 'blocked').length;
  const isMap = mode === 'satellite' || mode === 'standard';

  const save = async () => {
    if (!name.trim()) return Alert.alert('Name required', 'Give the building a name.');
    setSaving(true);
    try {
      // Everything saves LOCALLY so it appears in the list instantly and works
      // with the server off. A preset is bundled; a scan keeps its photo inline.
      let coord = region ? { latitude: region.latitude, longitude: region.longitude } : null;
      if (!coord && !preset) {
        const { status } = await Location.getForegroundPermissionsAsync();
        if (status === 'granted') { const loc = await Location.getCurrentPositionAsync({}); coord = { latitude: loc.coords.latitude, longitude: loc.coords.longitude }; }
      }
      const b = preset
        ? { ...preset, id: preset.id + '-' + Date.now(), name: name.trim(), address: address.trim() }
        : {
            id: 'local-' + Date.now(), name: name.trim(), address: address.trim(), coord,
            builtin: false, blueprint: !!photo, localBlueprint: photo?.base64 || null,
            exits, imgW: photo?.w || 0, imgH: photo?.h || 0, mapExits, scans: 1,
          };
      await addSavedBuilding(b);
      // Best-effort server copy for non-preset scans; never blocks the demo.
      if (!preset) { try { await addBuilding({ name: b.name, address: b.address, coord, blueprint: photo?.base64 || null, exits, imgW: photo?.w || 0, imgH: photo?.h || 0, mapExits }); } catch (e) {} }
      route.params?.onPick?.(b);
      if (navigation.canGoBack()) navigation.goBack();
    } catch (e) { Alert.alert('Could not save', 'Something went wrong saving this building.'); }
    finally { setSaving(false); }
  };

  return (
    <ScrollView style={s.wrap} contentContainerStyle={{ padding: 16, paddingTop: 20, paddingBottom: 40 }}>
      <View style={s.headerRow}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={s.back}><Ionicons name="arrow-back" size={18} color={colors.textSec} /></TouchableOpacity>
        <Text style={s.h1}>Scan a new building</Text>
      </View>

      <Text style={s.label}>Building name</Text>
      <TextInput value={name} onChangeText={setName} placeholder="Sunrise Office" placeholderTextColor={colors.muted} style={s.input} />
      <Text style={s.label}>Address</Text>
      <View style={{ flexDirection: 'row', gap: 8 }}>
        <TextInput value={address} onChangeText={setAddress} placeholder="1200 Warren Pkwy, Frisco TX" placeholderTextColor={colors.muted} style={[s.input, { flex: 1 }]} />
        <TouchableOpacity style={s.findBtn} onPress={findOnMap} disabled={locating}>
          {locating ? <ActivityIndicator color="#fff" /> : <Text style={s.findT}>Find</Text>}
        </TouchableOpacity>
      </View>

      <Text style={s.section}>Mark the exits</Text>
      <View style={s.seg}>
        {MODES.map((m) => {
          const on = mode === m.key;
          return (
            <TouchableOpacity key={m.key} style={[s.segItem, on && { backgroundColor: colors.brand }]} onPress={() => setMode(m.key)}>
              <Ionicons name={m.icon} size={14} color={on ? '#fff' : colors.textSec} />
              <Text style={[s.segT, { color: on ? '#fff' : colors.textSec }]}>{m.label}</Text>
            </TouchableOpacity>
          );
        })}
      </View>

      {isMap ? (
        !region ? (
          <View style={s.placeholder}>
            <Ionicons name="location-outline" size={26} color={colors.muted} />
            <Text style={s.phText}>Enter an address and tap Find to load the map.</Text>
          </View>
        ) : (
          <>
            <Text style={s.hint}>{preset ? 'Exits are preset for this building.' : 'Tap the building edges to drop exits · tap a pin to block, tap again to remove'}</Text>
            <View style={s.mapWrap}>
              <MapView style={{ flex: 1 }} provider={Platform.OS === 'android' ? PROVIDER_GOOGLE : undefined}
                mapType={mode === 'satellite' ? 'hybrid' : 'standard'} region={region}
                onPress={(e) => addMapExit(e.nativeEvent.coordinate)}>
                {mapExits.map((ex, i) => (
                  <Marker key={i} coordinate={{ latitude: ex.latitude, longitude: ex.longitude }} onPress={() => cycleMapExit(i)}>
                    <View style={[s.mapPin, { backgroundColor: ex.status === 'clear' ? colors.safe : colors.danger }]}>
                      <Ionicons name={ex.status === 'clear' ? 'exit-outline' : 'close'} size={15} color="#fff" />
                    </View>
                  </Marker>
                ))}
              </MapView>
            </View>
            <Text style={s.count}>{mapExits.length} map exit{mapExits.length === 1 ? '' : 's'}{mapBlocked ? ` · ${mapBlocked} blocked` : ''}</Text>
          </>
        )
      ) : (
        !photo ? (
          <>
            <TouchableOpacity style={s.dropzone} onPress={() => capture(true)}>
              <Ionicons name="camera-outline" size={30} color={colors.brand} />
              <Text style={s.dzText}>Photograph the posted floor plan</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => capture(false)} style={{ alignSelf: 'center', marginTop: 8 }}>
              <Text style={{ color: colors.brand, fontSize: 13, fontWeight: '500' }}>or choose from photos</Text>
            </TouchableOpacity>
          </>
        ) : (
          <>
            <Text style={s.hint}>{preset ? 'Exits are preset for this building.' : 'Tap plan to add · tap pin to block/clear · hold to remove'}</Text>
            <View style={[s.planBox, { aspectRatio: aspect }]} onLayout={(e) => setBox({ w: e.nativeEvent.layout.width, h: e.nativeEvent.layout.height })}>
              <Pressable style={StyleSheet.absoluteFill} onPress={addExit}>
                <Image source={{ uri: photo.uri }} style={{ width: '100%', height: '100%' }} resizeMode="cover" />
              </Pressable>
              {exits.map((ex, i) => (
                <TouchableOpacity key={i} onPress={() => toggleExit(i)} onLongPress={() => removeExit(i)}
                  style={[s.pin, { left: ex.x * box.w - 15, top: ex.y * box.h - 15, backgroundColor: ex.status === 'clear' ? colors.safe : colors.danger }]}>
                  <Ionicons name={ex.status === 'clear' ? 'exit-outline' : 'close'} size={16} color="#fff" />
                </TouchableOpacity>
              ))}
            </View>
            {!preset && (
              <TouchableOpacity onPress={() => capture(true)} style={{ alignSelf: 'center', marginTop: 6 }}>
                <Text style={{ color: colors.brand, fontSize: 13, fontWeight: '500' }}>retake photo</Text>
              </TouchableOpacity>
            )}
          </>
        )
      )}

      <TouchableOpacity style={[s.cta, saving && { opacity: 0.7 }]} onPress={save} disabled={saving}>
        {saving ? <ActivityIndicator color="#fff" /> : <Text style={s.ctaT}>Save building</Text>}
      </TouchableOpacity>
    </ScrollView>
  );
}

function makeStyles(c) {
  return StyleSheet.create({
    wrap: { flex: 1, backgroundColor: c.surface },
    headerRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 12 },
    back: { width: 34, height: 34, borderRadius: 10, backgroundColor: c.surfaceAlt, alignItems: 'center', justifyContent: 'center' },
    h1: { fontSize: 18, fontWeight: '500', color: c.ink },
    label: { fontSize: 12, color: c.textSec, fontWeight: '500', marginBottom: 6, marginTop: 10 },
    input: { borderWidth: 1, borderColor: c.borderInput, borderRadius: 11, padding: 12, fontSize: 14, backgroundColor: c.card, color: c.ink },
    findBtn: { backgroundColor: c.brand, borderRadius: 11, paddingHorizontal: 18, alignItems: 'center', justifyContent: 'center' },
    findT: { color: '#fff', fontWeight: '500', fontSize: 14 },
    presetBanner: { flexDirection: 'row', alignItems: 'center', gap: 7, backgroundColor: c.tint, borderRadius: 10, padding: 10, marginTop: 10 },
    presetT: { fontSize: 12, color: c.brandDark, fontWeight: '500', flex: 1 },
    section: { fontSize: 15, fontWeight: '500', color: c.ink, marginTop: 20, marginBottom: 8 },
    seg: { flexDirection: 'row', backgroundColor: c.surfaceAlt, borderRadius: 11, padding: 3, marginBottom: 10 },
    segItem: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5, paddingVertical: 8, borderRadius: 9 },
    segT: { fontSize: 13, fontWeight: '500' },
    hint: { fontSize: 11, color: c.muted, marginBottom: 8 },
    placeholder: { height: 160, borderRadius: 12, borderWidth: 1, borderColor: c.border, backgroundColor: c.card, alignItems: 'center', justifyContent: 'center', gap: 8, padding: 16 },
    phText: { fontSize: 13, color: c.muted, textAlign: 'center' },
    mapWrap: { height: 240, borderRadius: 12, overflow: 'hidden', borderWidth: 1, borderColor: c.border },
    mapPin: { width: 28, height: 28, borderRadius: 14, alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: '#fff' },
    count: { fontSize: 12, color: c.ink, fontWeight: '500', marginTop: 8 },
    dropzone: { height: 160, borderRadius: 12, borderWidth: 2, borderStyle: 'dashed', borderColor: c.border, backgroundColor: c.card, alignItems: 'center', justifyContent: 'center' },
    dzText: { color: c.textSec, fontSize: 13, marginTop: 8 },
    planBox: { width: '100%', borderRadius: 12, overflow: 'hidden', backgroundColor: c.surfaceAlt, position: 'relative' },
    pin: { position: 'absolute', width: 30, height: 30, borderRadius: 15, alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: '#fff' },
    cta: { backgroundColor: c.brand, borderRadius: 13, padding: 15, alignItems: 'center', marginTop: 22 },
    ctaT: { color: '#fff', fontSize: 15, fontWeight: '500' },
  });
}
