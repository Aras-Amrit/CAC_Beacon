import React, { useMemo } from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet, Linking, Platform } from 'react-native';
import MapView, { Marker, PROVIDER_GOOGLE } from 'react-native-maps';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../ThemeContext';
import { circle, statusMeta } from '../data';

export default function PersonDetail({ route, navigation }) {
  const { colors } = useTheme();
  const s = useMemo(() => makeStyles(colors), [colors]);
  const p = circle.find((x) => x.id === route.params.id);
  const m = statusMeta[p.status];
  const directions = () => Linking.openURL(`https://www.google.com/maps/dir/?api=1&destination=${p.coord.latitude},${p.coord.longitude}`);
  const call = () => Linking.openURL('tel:+14695550134');

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.surface }} contentContainerStyle={{ padding: 16 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 14 }}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={s.back}><Ionicons name="arrow-back" size={18} color={colors.textSec} /></TouchableOpacity>
        <View style={{ flex: 1 }}>
          <Text style={{ fontSize: 16, fontWeight: '500', color: colors.ink }}>{p.name}</Text>
          <Text style={{ fontSize: 11, fontWeight: '500', color: m.color }}>{m.label}</Text>
        </View>
      </View>
      <View style={s.mapWrap}>
        <MapView style={{ flex: 1 }} provider={Platform.OS === 'android' ? PROVIDER_GOOGLE : undefined}
          initialRegion={{ ...p.coord, latitudeDelta: 0.004, longitudeDelta: 0.004 }} pointerEvents="none" userInterfaceStyle={colors.mode}>
          <Marker coordinate={p.coord}><View style={[s.pin, { backgroundColor: m.color }]} /></Marker>
        </MapView>
      </View>
      <View style={s.infoCard}>
        <Ionicons name="location-outline" size={20} color={colors.brand} />
        <View style={{ flex: 1, marginLeft: 10 }}>
          <Text style={{ fontSize: 13, fontWeight: '500', color: colors.ink }}>{p.where}</Text>
          <Text style={{ fontSize: 11, color: colors.muted }}>{p.inBuilding ? 'Sunrise Office · Floor 3' : 'Tap for live directions'}</Text>
        </View>
      </View>
      <TouchableOpacity style={s.dirBtn} onPress={directions}>
        <Ionicons name="navigate" size={17} color="#fff" />
        <Text style={{ color: '#fff', fontSize: 14, fontWeight: '500', marginLeft: 8 }}>Get directions in Google Maps</Text>
      </TouchableOpacity>
      <TouchableOpacity style={s.callBtn} onPress={call}>
        <Ionicons name="call" size={16} color={colors.brand} />
        <Text style={{ color: colors.ink, fontSize: 14, fontWeight: '500', marginLeft: 8 }}>Call {p.name.split(' ')[0]}</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

function makeStyles(c) {
  return StyleSheet.create({
    back: { width: 34, height: 34, borderRadius: 10, backgroundColor: c.surfaceAlt, alignItems: 'center', justifyContent: 'center' },
    mapWrap: { height: 190, borderRadius: 12, overflow: 'hidden' },
    pin: { width: 18, height: 18, borderRadius: 9, borderWidth: 3, borderColor: '#fff' },
    infoCard: { flexDirection: 'row', alignItems: 'center', backgroundColor: c.card, borderWidth: 1, borderColor: c.border, borderRadius: 13, padding: 13, marginTop: 12 },
    dirBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: c.brand, borderRadius: 13, padding: 14, marginTop: 10 },
    callBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: c.card, borderWidth: 1, borderColor: c.border, borderRadius: 13, padding: 13, marginTop: 9 },
  });
}
