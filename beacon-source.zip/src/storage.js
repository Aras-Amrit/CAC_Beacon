import AsyncStorage from '@react-native-async-storage/async-storage';

const K = {
  onboarded: '@beacon/onboarded',
  role: '@beacon/role',
  building: '@beacon/building',
  profile: '@beacon/profile',
  saved: '@beacon/savedBuildings',   // locally added buildings (presets + scans)
};

export async function loadState() {
  try {
    const [onboarded, role, building, profile] = await Promise.all([
      AsyncStorage.getItem(K.onboarded),
      AsyncStorage.getItem(K.role),
      AsyncStorage.getItem(K.building),
      AsyncStorage.getItem(K.profile),
    ]);
    return {
      onboarded: onboarded === '1',
      role: role || 'community',
      building: building ? JSON.parse(building) : null,
      profile: profile ? JSON.parse(profile) : null,
    };
  } catch (e) {
    return { onboarded: false, role: 'community', building: null, profile: null };
  }
}

export const saveOnboarded = (role, profile) =>
  Promise.all([
    AsyncStorage.setItem(K.onboarded, '1'),
    AsyncStorage.setItem(K.role, role),
    profile ? AsyncStorage.setItem(K.profile, JSON.stringify(profile)) : Promise.resolve(),
  ]);

export const saveRole = (role) => AsyncStorage.setItem(K.role, role);
export const saveBuilding = (b) => AsyncStorage.setItem(K.building, JSON.stringify(b));
export const resetAll = () => AsyncStorage.multiRemove(Object.values(K));

// --- Locally saved buildings (work with the server off) ---
export async function getSavedBuildings() {
  try {
    const raw = await AsyncStorage.getItem(K.saved);
    return raw ? JSON.parse(raw) : [];
  } catch (e) { return []; }
}
export async function addSavedBuilding(b) {
  try {
    const list = await getSavedBuildings();
    const next = [b, ...list.filter((x) => x.id !== b.id)];
    await AsyncStorage.setItem(K.saved, JSON.stringify(next));
    return next;
  } catch (e) { return [b]; }
}
export async function removeSavedBuilding(id) {
  try {
    const list = await getSavedBuildings();
    const next = list.filter((x) => x.id !== id);
    await AsyncStorage.setItem(K.saved, JSON.stringify(next));
    return next;
  } catch (e) { return []; }
}
