import React, { createContext, useContext, useEffect, useState } from 'react';
import { Appearance } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { light, dark } from './theme';
const ThemeCtx = createContext({ colors: light, dark: false, toggle: () => {} });
export const useTheme = () => useContext(ThemeCtx);
const KEY = '@beacon/theme';
export function ThemeProvider({ children }) {
  const [isDark, setIsDark] = useState(Appearance.getColorScheme() === 'dark');
  useEffect(() => { AsyncStorage.getItem(KEY).then((v) => { if (v === 'dark') setIsDark(true); else if (v === 'light') setIsDark(false); }); }, []);
  const toggle = () => setIsDark((d) => { const next = !d; AsyncStorage.setItem(KEY, next ? 'dark' : 'light'); return next; });
  return <ThemeCtx.Provider value={{ colors: isDark ? dark : light, dark: isDark, toggle }}>{children}</ThemeCtx.Provider>;
}
