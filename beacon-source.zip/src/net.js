import { io } from 'socket.io-client';

// Your Mac's LAN IP + the server port. Update the IP if your network changes
// (find it with `ipconfig getifaddr en0`). Phone + Mac must share Wi-Fi.
export const API_URL = 'http://10.0.0.43:4000';

let socket = null;

export function connectPresence(me, onPeers) {
  socket = io(API_URL, { transports: ['websocket'] });
  socket.on('connect', () => socket.emit('join', me));
  socket.on('peers', (peers) => onPeers(peers.filter((p) => p.id !== me.id)));
  return () => { if (socket) { socket.disconnect(); socket = null; } };
}

export function updateMe(me) {
  if (socket && socket.connected) socket.emit('update', me);
}

export async function listBuildings() {
  const res = await fetch(`${API_URL}/buildings`);
  return res.json();
}

export async function addBuilding(payload) {
  const res = await fetch(`${API_URL}/buildings`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  return res.json();
}

export async function deleteBuilding(id) {
  const res = await fetch(`${API_URL}/buildings/${id}`, { method: 'DELETE' });
  return res.json();
}
