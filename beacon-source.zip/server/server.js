// Beacon backend — realtime presence + building registry.
// Run: cd server && npm install && node server.js
const express = require('express');
const http = require('http');
const cors = require('cors');
const { Server } = require('socket.io');

const app = express();
app.use(cors());
app.use(express.json({ limit: '12mb' })); // blueprints are base64 images

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

// --- Building registry (in-memory; swap for a DB later) ---
// exits: [{ x, y, status }]  x/y are 0..1 fractions of the plan image; status 'clear'|'blocked'
let buildings = [
  { id: 'b1', name: 'Sunrise Office', address: '1200 Warren Pkwy, Frisco TX',
    coord: { latitude: 33.1207, longitude: -96.8117 }, blueprint: null,
    exits: [], imgW: 0, imgH: 0, mapExits: [], scans: 1 },
];

// list without the heavy base64 payload — exits are small, keep them
const summary = (b) => ({
  id: b.id, name: b.name, address: b.address, coord: b.coord,
  blueprint: !!b.blueprint, exits: b.exits || [], imgW: b.imgW || 0, imgH: b.imgH || 0, mapExits: b.mapExits || [], scans: b.scans,
});

app.get('/buildings', (req, res) => res.json(buildings.map(summary)));

app.get('/buildings/:id/blueprint', (req, res) => {
  const b = buildings.find((x) => x.id === req.params.id);
  if (!b || !b.blueprint) return res.sendStatus(404);
  const m = /^data:(.+?);base64,(.*)$/.exec(b.blueprint);
  if (!m) return res.sendStatus(404);
  res.set('Content-Type', m[1]);
  res.send(Buffer.from(m[2], 'base64'));
});

app.delete('/buildings/:id', (req, res) => {
  buildings = buildings.filter((b) => b.id !== req.params.id);
  io.emit('buildings', buildings.map(summary));
  res.json({ ok: true });
});

app.post('/buildings', (req, res) => {
  const { name, address, coord, blueprint, exits, imgW, imgH, mapExits } = req.body;
  const b = {
    id: 'b' + Date.now(), name, address: address || '', coord: coord || null,
    blueprint: blueprint || null, exits: Array.isArray(exits) ? exits : [],
    imgW: imgW || 0, imgH: imgH || 0, mapExits: Array.isArray(mapExits) ? mapExits : [], scans: 1,
  };
  buildings.push(b);
  io.emit('buildings', buildings.map(summary));
  res.json(summary(b));
});

// --- Live presence ---
const peers = new Map(); // id -> { id, name, coord, status, buildingId, ts, socketId }

function broadcast() {
  const now = Date.now();
  for (const [id, p] of peers) if (now - p.ts > 30000) peers.delete(id);
  io.emit('peers', Array.from(peers.values()));
}

io.on('connection', (socket) => {
  socket.on('join', (me) => { peers.set(me.id, { ...me, ts: Date.now(), socketId: socket.id }); broadcast(); });
  socket.on('update', (me) => { peers.set(me.id, { ...me, ts: Date.now(), socketId: socket.id }); broadcast(); });
  socket.on('disconnect', () => {
    for (const [id, p] of peers) if (p.socketId === socket.id) peers.delete(id);
    broadcast();
  });
});

setInterval(broadcast, 10000);

const PORT = process.env.PORT || 4000;
server.listen(PORT, () => console.log(`Beacon server on :${PORT}`));
